package at.ac.fhcampuswien.alcatraz.shared.exception;

public class FullSessionException extends RuntimeException {

    public FullSessionException(String message) {
        super(message);
    }
}
