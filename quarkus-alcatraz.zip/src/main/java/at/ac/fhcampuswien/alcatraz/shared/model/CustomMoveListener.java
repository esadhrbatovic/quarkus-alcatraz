package at.ac.fhcampuswien.alcatraz.shared.model;

import at.falb.games.alcatraz.api.MoveListener;


public interface CustomMoveListener extends MoveListener {
}
