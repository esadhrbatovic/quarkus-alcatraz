package at.ac.fhcampuswien.alcatraz.shared.exception;

public class GameRunningException extends RuntimeException {

    public GameRunningException(String message) {
        super(message);
    }
}
