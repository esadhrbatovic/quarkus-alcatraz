package at.ac.fhcampuswien.alcatraz.shared.exception;

public class TimeOutException extends RuntimeException {

    public TimeOutException(String message) {
        super(message);
    }
}
