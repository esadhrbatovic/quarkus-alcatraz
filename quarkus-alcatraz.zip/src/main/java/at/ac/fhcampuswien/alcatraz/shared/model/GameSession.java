package at.ac.fhcampuswien.alcatraz.shared.model;

import java.io.Serializable;
import java.util.ArrayList;

public class GameSession<NetPlayer> extends ArrayList<NetPlayer> implements Serializable {

}
